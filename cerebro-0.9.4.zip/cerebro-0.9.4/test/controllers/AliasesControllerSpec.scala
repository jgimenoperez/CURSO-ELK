package controllers

/**
  * Created by leo on 08/08/16.
  */
class AliasesControllerSpec {

}
