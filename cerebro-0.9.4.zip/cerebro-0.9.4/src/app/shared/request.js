// eslint-disable-next-line no-unused-vars
function Request(path, method, body) {
  this.path = path;

  this.method = method;

  this.body = body;
}
