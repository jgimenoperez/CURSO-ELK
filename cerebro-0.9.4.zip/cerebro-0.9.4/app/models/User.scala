package models

case class User(name: String)
