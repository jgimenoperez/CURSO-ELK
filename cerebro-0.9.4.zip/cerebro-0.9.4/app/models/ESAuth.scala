package models

case class ESAuth(username: String, password: String)
